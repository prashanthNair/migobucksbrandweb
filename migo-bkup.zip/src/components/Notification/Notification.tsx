import React from 'react';

function Notify(props: any) {
    return (
        <div className={props.className}> Notify</div>
    )
}

export default Notify;