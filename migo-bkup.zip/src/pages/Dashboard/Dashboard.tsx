import React from 'react';

import style from './Dashboard.module.scss';

function Dashboard() {
    return (
        <div className={style['page-dashboard']}>
            <h1>Welcome to dashboard</h1>
        </div>
    )
}

export default Dashboard
