import { createStore } from "redux";
import rootReducer from "./reducer";

export default createStore(rootReducer);